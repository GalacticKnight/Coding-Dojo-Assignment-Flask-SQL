for this assignment, i may have re-engineered the mysql table in the local host server but NOT in the eer diagram. So if the code breaks, can you email me before you make the final grade? I wish to send you the actual database that works IF anything goes wrong.'

I put the mwb file in the Exam folder.

Also i look foward to the code review today at 6.
See you there!